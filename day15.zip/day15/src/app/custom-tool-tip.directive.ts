import { Directive, OnInit ,Input} from '@angular/core';

@Directive({
  selector: '[customToolTip]'
})
export class CustomToolTipDirective implements OnInit {
@Input() customToolTip:string;
  constructor() { 
    this.customToolTip="";
  }
  ngOnInit(): void {
   console.log(this.customToolTip);
  }

}

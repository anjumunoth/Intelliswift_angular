import { Component } from '@angular/core';

@Component({
  selector: 'app-sample-pipe-examples',
  templateUrl: './sample-pipe-examples.component.html',
  styleUrls: ['./sample-pipe-examples.component.css']
})
export class SamplePipeExamplesComponent {

  myCountries:string[];
  constructor()
  {
    this.myCountries=["India","Mexico","Australia","Ireland","Germany"];
  }
}

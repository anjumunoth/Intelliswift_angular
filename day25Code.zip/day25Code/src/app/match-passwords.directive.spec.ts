import { MatchPasswordsDirective } from './match-passwords.directive';

describe('MatchPasswordsDirective', () => {
  it('should create an instance', () => {
    const directive = new MatchPasswordsDirective();
    expect(directive).toBeTruthy();
  });
});

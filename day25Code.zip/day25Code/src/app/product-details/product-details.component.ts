import { Component, Input } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { WorkWithProductsService } from '../work-with-products.service';
import { Products } from '../products';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css']
})
export class ProductDetailsComponent {
  @Input() pId:string;
  selectedProductId: string;
  selectedProduct:Products|null;
  constructor(private activatedRoute:ActivatedRoute,private productsArrayService:WorkWithProductsService)
  {
    //this.selectedProductId=this.activatedRoute.snapshot.params["pId"]
    this.selectedProductId=this.activatedRoute.snapshot.paramMap.get("pId") ?? "undefined";
    this.pId="";
    var productId=parseInt(this.selectedProductId);
    var product=productsArrayService.getProductDetail(productId);
    if(product)
      {
        this.selectedProduct=product;
      }
    else
    {
      this.selectedProduct=null;
    }

  }

}

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SamplePipeExamplesComponent } from './sample-pipe-examples.component';

describe('SamplePipeExamplesComponent', () => {
  let component: SamplePipeExamplesComponent;
  let fixture: ComponentFixture<SamplePipeExamplesComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SamplePipeExamplesComponent]
    });
    fixture = TestBed.createComponent(SamplePipeExamplesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

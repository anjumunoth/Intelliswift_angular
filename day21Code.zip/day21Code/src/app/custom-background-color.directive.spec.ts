import { CustomBackgroundColorDirective } from './custom-background-color.directive';

describe('CustomBackgroundColorDirective', () => {
  it('should create an instance', () => {
    const directive = new CustomBackgroundColorDirective();
    expect(directive).toBeTruthy();
  });
});

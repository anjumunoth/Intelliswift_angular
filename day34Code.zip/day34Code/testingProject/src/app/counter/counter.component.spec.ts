import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CounterComponent } from './counter.component';
import { CounterManageService } from '../counter-manage.service';

describe('CounterComponent', () => {
  let component: CounterComponent;
  let fixture: ComponentFixture<CounterComponent>;
  let service:CounterManageService;
  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CounterComponent],
      providers:[CounterManageService]
    });
    fixture = TestBed.createComponent(CounterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    service=TestBed.inject(CounterManageService);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it("should have the intial value as 0 for ctr",()=>{
    expect(component.ctr).toBe(0);
  })
  it("should increment the value of ctr on clicking the + button",()=>
  {
    component.ctr=0;
    // emulate the click event of + button
    var plusButtonElement=fixture.nativeElement.querySelector("#plusButton");
    plusButtonElement.click();
    expect(component.ctr).toBe(1);
  })
});

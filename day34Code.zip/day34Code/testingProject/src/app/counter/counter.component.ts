import { Component } from '@angular/core';
import { CounterManageService } from '../counter-manage.service';

@Component({
  selector: 'app-counter',
  templateUrl: './counter.component.html',
  styleUrls: ['./counter.component.css']
})
export class CounterComponent {
ctr:number;
constructor(private counterManageService:CounterManageService)
{
  this.ctr=counterManageService.ctr;
}
changeCtr(op:string)
{
  if(op=="inc")
    {
      this.counterManageService.incrementCtr();
      this.ctr=this.counterManageService.ctr;
    }
    else
    {
      this.ctr--;
    }

}
}

import { Injectable } from '@angular/core';

@Injectable()
export class CounterManageService {
  ctr:number;
  constructor() {
    this.ctr=0;
   }
   incrementCtr()
   {
    this.ctr++;
   }
}

import { TestBed } from '@angular/core/testing';

import { CounterManageService } from './counter-manage.service';

describe('CounterManageService', () => {
  let service: CounterManageService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CounterManageService);
  });

  xit('should be created', () => {
    expect(service).toBeTruthy();
  });
});

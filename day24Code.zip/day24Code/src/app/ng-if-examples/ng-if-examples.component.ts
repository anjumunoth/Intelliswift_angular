import { Component } from '@angular/core';

@Component({
  selector: 'app-ng-if-examples',
  templateUrl: './ng-if-examples.component.html',
  styleUrls: ['./ng-if-examples.component.css']
})
export class NgIfExamplesComponent {
  shouldUpdate:boolean;
  constructor()
  {
    this.shouldUpdate=true;
    var i=10;
    console.log("hi");
    console.log(i);
    if(i>1)
      {

      }
      else
      {
        
      }
  }
}

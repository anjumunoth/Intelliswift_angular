import { Directive, OnInit ,Input, HostListener,ElementRef,Renderer2} from '@angular/core';

@Directive({
  selector: '[customToolTip]'
})
export class CustomToolTipDirective implements OnInit {
  private companyName:string;
  toolTipElement:any;
@Input() customToolTip:string;
@HostListener("mouseenter") onMouseEnter(){
  var divElement=this.renderer.createElement("span");
  this.toolTipElement=divElement;
  var textElement=this.renderer.createText(this.customToolTip);
  divElement.appendChild(textElement);
  this.renderer.appendChild(this.el.nativeElement,divElement);
  //this.renderer.setStyle(divElement,"background-color","beige");
  this.renderer.addClass(divElement,"bg-primary");
  this.renderer.setStyle(divElement,"color","yellow");
  this.renderer.setStyle(divElement,"border","3px solid yellow");
  this.renderer.setStyle(divElement,"z-index",100);
  this.renderer.setStyle(divElement,"position","relative");
  this.renderer.setStyle(divElement,"font-size","small");
  // top of the element
  var hostPos=this.el.nativeElement.getBoundingClientRect();
  let top=hostPos.bottom-10;
  let left=hostPos.left+10;
  this.renderer.setStyle(divElement,"top",top);
  this.renderer.setStyle(divElement,"left",left);
  

}
@HostListener("mouseleave") onMouseLeave(){
  this.renderer.removeChild(this.el.nativeElement,this.toolTipElement);
  this.toolTipElement=null;
}


  constructor(private el:ElementRef,private renderer:Renderer2) { 
    this.customToolTip="";
    this.companyName="Intelliswift";
  }
  ngOnInit(): void {
   console.log(this.customToolTip);
  }

}

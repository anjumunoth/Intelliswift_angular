import { Component } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

@Component({
  selector: 'app-demo',
  templateUrl: './demo.component.html',
  styleUrls: ['./demo.component.css']
})
export class DemoComponent {
  fruits:Array<string>;
  products:BehaviorSubject<Array<string>>;
  constructor()
  {
    this.fruits=["apple","strawberry","banana"];
    this.products=new BehaviorSubject<Array<string>>(["ipad","iphone"]);
  }
  addFruitEventHandler(fruit:string)
  {
    this.fruits.push(fruit);// changes the original array; mutating the data
    //this.fruits=[...this.fruits,fruit];// copy of array; immutability
    console.log("Fruits",this.fruits);
  }
  addProductEventHandler(product:string)
  {
    this.products.next([product]);
  }
}

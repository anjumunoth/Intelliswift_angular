import { Component,Input } from '@angular/core';
import { Tasks } from '../tasks';
import { Store } from '@ngrx/store';
import { TasksActions } from '../store/task.action';

@Component({
  selector: 'app-tasks-list',
  templateUrl: './tasks-list.component.html',
  styleUrls: ['./tasks-list.component.css']
})
export class TasksListComponent {
@Input() todos:Array<Tasks>;
constructor(private store:Store)
{
  this.todos=[];
}
completedEventHandler(task:Tasks)
{
  // added to the completed Tasks List;
  // dispatch an action
  this.store.dispatch(TasksActions.markTaskAsCompleted({task}));
}
}

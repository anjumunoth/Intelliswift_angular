import { createActionGroup, props } from "@ngrx/store";
import { Tasks } from "../tasks";

export const TasksApiActions=createActionGroup({
    source:"Tasks API",
    events:{
        "Load Tasks": props<{tasksArr:Array<Tasks>}>()
    }

});

// create another action group with 3 events-- add, remove ,mark as completed

export const TasksActions=createActionGroup({
    source:"Tasks",
    events:{
        "Add Task": props<{task:Tasks}>(),
        "Delete Task": props<{taskId:number}>(),
        "Mark Task As Completed":props<{task:Tasks}>()
    }
})
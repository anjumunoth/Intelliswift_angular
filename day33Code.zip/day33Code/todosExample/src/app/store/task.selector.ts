import {  createFeatureSelector } from "@ngrx/store";
import { Tasks } from "../tasks";

export var selectTasks=createFeatureSelector<Array<Tasks>>("tasks")

export var selectCompletedTasks=createFeatureSelector<Array<Tasks>>("completedTasks")
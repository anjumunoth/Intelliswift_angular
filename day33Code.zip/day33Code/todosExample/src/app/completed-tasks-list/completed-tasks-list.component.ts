import { Tasks } from "../tasks";
import { Component,Input } from '@angular/core';

@Component({
  selector: 'app-completed-tasks-list',
  templateUrl: './completed-tasks-list.component.html',
  styleUrls: ['./completed-tasks-list.component.css']
})
export class CompletedTasksListComponent {
@Input() completedTasks:Array<Tasks>;
constructor()
{
  this.completedTasks=[];
}
}

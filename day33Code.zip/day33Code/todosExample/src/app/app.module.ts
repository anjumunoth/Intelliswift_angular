import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {HttpClientModule} from "@angular/common/http"

import { AppComponent } from './app.component';
import { StoreModule } from '@ngrx/store';

import {completedTasksReducer} from "./store/completedTasks.reducer"
import {tasksReducer} from "./store/task.reducer";
import { TasksListComponent } from './tasks-list/tasks-list.component';
import { CompletedTasksListComponent } from './completed-tasks-list/completed-tasks-list.component';
import { DemoComponent } from './demo/demo.component';
import { FruitDisplayComponent } from './fruit-display/fruit-display.component';
import { ProductDisplayComponent } from './product-display/product-display.component';
import { AnUnusedComponent } from './an-unused/an-unused.component'

@NgModule({
  declarations: [
    AppComponent,
    TasksListComponent,
    CompletedTasksListComponent,
    DemoComponent,
    FruitDisplayComponent,
    ProductDisplayComponent,
    AnUnusedComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    StoreModule.forRoot({tasks:tasksReducer,completedTasks:completedTasksReducer}, {})
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

import { ChangeDetectionStrategy, ChangeDetectorRef, Component,Input, OnInit } from '@angular/core';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-product-display',
  templateUrl: './product-display.component.html',
  styleUrls: ['./product-display.component.css'],
  changeDetection:ChangeDetectionStrategy.OnPush
})
export class ProductDisplayComponent implements OnInit {
@Input() products:Observable<Array<string>>;
productsArr:Array<string>;
constructor(private changeDetector:ChangeDetectorRef)
{
  this.products=new Observable<Array<string>>();
  this.productsArr=[];
} 
  ngOnInit(): void {
    this.products.subscribe((value)=>{
      this.productsArr=[...this.productsArr,...value];
      this.changeDetector.markForCheck()
    })
  }

}

import { Component } from '@angular/core';

@Component({
  selector: 'app-an-unused',
  templateUrl: './an-unused.component.html',
  styleUrls: ['./an-unused.component.css']
})
export class AnUnusedComponent {

}

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AnUnusedComponent } from './an-unused.component';

describe('AnUnusedComponent', () => {
  let component: AnUnusedComponent;
  let fixture: ComponentFixture<AnUnusedComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AnUnusedComponent]
    });
    fixture = TestBed.createComponent(AnUnusedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

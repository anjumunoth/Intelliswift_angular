import { Component, OnInit } from '@angular/core';
import { TasksManageService } from './tasks-manage.service';
import { Store } from '@ngrx/store';
import { TasksApiActions } from './store/task.action';
import { Tasks } from './tasks';
import { Observable } from 'rxjs';
import { selectCompletedTasks, selectTasks } from './store/task.selector';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'todosExample';
  tasks$:Observable<Array<Tasks>>;
  completedTasks$:Observable<Array<Tasks>>;
  constructor(private tasksManage:TasksManageService, private store:Store)
  {
    this.tasks$=this.store.select(selectTasks);
    this.completedTasks$=this.store.select(selectCompletedTasks);
  }
  ngOnInit(): void {
    this.tasksManage.getAllTasks()
    .subscribe((tasksArr:Array<Tasks>)=>{
      // dispatch an action
      this.store.dispatch(TasksApiActions.loadTasks({tasksArr}))
    })
  }

}

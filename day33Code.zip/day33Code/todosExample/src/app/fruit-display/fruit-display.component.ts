import { ChangeDetectionStrategy, ChangeDetectorRef, Component, Input } from '@angular/core';

@Component({
  selector: 'app-fruit-display',
  templateUrl: './fruit-display.component.html',
  styleUrls: ['./fruit-display.component.css'],
  changeDetection:ChangeDetectionStrategy.OnPush
})
export class FruitDisplayComponent {
@Input() fruits:Array<string>;
constructor(private cd:ChangeDetectorRef)
{
  this.fruits=[];
}
refreshEventHandler()
{
  // manually trigger the change detection
  this.cd.detectChanges();
}
}

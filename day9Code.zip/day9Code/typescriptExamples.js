//typescript;

// Strongly typed languauge

var i:number=10;

//i="hello";//error

var str1:string="monday";

var isVisible:boolean=false;

var empObj:Object={empId:101,empName:"sara"};

var arr1:number[]=[1,2,3];

var ctr:any=100;//any data type;
ctr="One hundred";

class Employee
{
    empId:number;
    empName:string;
}

var emp1:Employee=new Employee();

//int i=10;
// ts --- js+ additional features
//js
//var, let, const


// Linting rules: rules to be followed during development-- warnings will occur during compilation
var i=10;
var j= 10;
var k = 10;
// naming convention 
var empId, emp_id, emp-id;


var  rainbowColours:string[]=["violet","indigo","brown","green","yellow","orange","red"];
 
var studArr:any[]=["101","sara","english",56,78];


class Employee
{
    empId:number;
    empName:string;
}

/* Decorators
-- just before the class declaration
-- takes in one parameter -- configuration object
-- Class has the additional functionality of decorators
-- Start with @ symbol
-- @NgModule,@Component, @Directive, @Pipe
-- Imported from @angular/core
*/

@Ngmodule({
    
})
class AppModule
{}

/*
class -- data and methods which work on that data

interface -- rules that a class has to adhere to compulsarily




interface SalaryManage
{
    checkSalary();
    bonus : number;
}

interface NameManage()
{
    checkName()
}


class Employee implements SalaryManage, NameManage
{
    empId:number;
    empName:string;
    salary:number;
    constructor()
    {
        // bonus initialisation is mandatory since we have implemented the interface
        this.bonus=this.salary*.3;
        // this.bonus=10;
    }
    // give a definition for the functions in the interface
    checkSalary()
    {
        return salary > 10000;
    }
    checkName()
    {
        return name.length>0;
    }
}

var ctr:number=10;

function incrementCtr(num1:number) :number
{
    return ctr+num1;
}

*/

function sumOfTwoNumbers(num1,num2)
{
    // pure function -- returns the same output given the same input
    // no side effects
    // deterministic
    return num1+num2;
}
function sumOfTwoNumbersWithRandomisation(num1,num2)
{
    //impure function -- returns different output for the same input
    return num1+num2+Math.random();
}


sumOfTwoNumbers(10,20);//30
sumOfTwoNumbers(10,20);//30
sumOfTwoNumbers(20,30);//50

sumOfTwoNumbersWithRandomisation(10,20);//30.5
sumOfTwoNumbersWithRandomisation(100,200);//300.7
sumOfTwoNumbersWithRandomisation(10,20);//30.1
import { Component } from '@angular/core';

@Component({
  selector: 'app-payment-by-pay-pal',
  templateUrl: './payment-by-pay-pal.component.html',
  styleUrls: ['./payment-by-pay-pal.component.css']
})
export class PaymentByPayPalComponent {

}

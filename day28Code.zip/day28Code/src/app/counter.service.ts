import { Injectable } from '@angular/core';

@Injectable()
export class CounterService {
  ctr:number;
  constructor() { 
    this.ctr=0;
  }
  incCtr()
  {
    this.ctr++;
    return this.ctr;
  }
  decCtr(){
    this.ctr--;
    return this.ctr;
  }

}

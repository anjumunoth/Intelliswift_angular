import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'displayArray'
})
export class DisplayArrayPipe implements PipeTransform {

  transform(value: string[], ...args: unknown[]): string[] {
    return value
  }

}

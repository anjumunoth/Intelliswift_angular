import { Component, OnInit, inject } from '@angular/core';
import { TalkWithServerService } from '../talk-with-server.service';

@Component({
  selector: 'app-users-manage',
  templateUrl: './users-manage.component.html',
  styleUrls: ['./users-manage.component.css']
})
export class UsersManageComponent implements OnInit{
  talkWithServer:TalkWithServerService;
  usersArr:Array<Object>;
  constructor()
  {
    this.talkWithServer=inject(TalkWithServerService);
    this.usersArr=[];
  }
  ngOnInit(): void {
   this.talkWithServer.getAllUsers()
   .subscribe({
      next:(response)=>{
        console.log(`Response of get request : ${JSON.stringify(response)}`)
        this.usersArr=response;
      }
      
    }
   )
  }
}

// constructor will be executed and then UI will be loaded and then ngOnInit will be executed

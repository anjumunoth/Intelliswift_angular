import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class TalkWithServerService {
  serverUrl:string;
  constructor(private httpClient:HttpClient) {
    this.serverUrl="https://jsonplaceholder.typicode.com/"
   }

   getAllUsers()
   {
      this.serverUrl="https://jsonplaceholder.typicode.com/users";
      //GET request-- getting data from api; select query ; no need tp pass any data as part of body section; pass some header info; pass some params; pass some query string;authentication info(tokens)
      // response -- data, Content-type; header info; status code 
      // status 200, 201, 202... success code
      // 300, 301
      // 400, 401.... error codes 
      // 500 -- Interal server error
      //this.httpClient.get(this.serverUrl)
      return this.httpClient.get<Array<Object>>(this.serverUrl)
      // get request -- Observable with data of data type Array<Object>
      

   }

}

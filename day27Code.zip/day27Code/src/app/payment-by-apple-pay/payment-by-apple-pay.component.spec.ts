import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PaymentByApplePayComponent } from './payment-by-apple-pay.component';

describe('PaymentByApplePayComponent', () => {
  let component: PaymentByApplePayComponent;
  let fixture: ComponentFixture<PaymentByApplePayComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [PaymentByApplePayComponent]
    });
    fixture = TestBed.createComponent(PaymentByApplePayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

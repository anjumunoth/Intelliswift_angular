import { Component } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { passwordStrengthValidator } from '../../Validators/passwordStrengthValidator';
import { checkPasswordMatching } from 'src/Validators/checkPasswordMatching';

@Component({
  selector: 'app-register-reactive-form',
  templateUrl: './register-reactive-form.component.html',
  styleUrls: ['./register-reactive-form.component.css']
})
export class RegisterReactiveFormComponent {
  registerReactive: FormGroup;
  constructor(private fb: FormBuilder) {
    /*First Way
    // this.registerReactive=new FormGroup({
    //   "firstName":new FormControl("",Validators.required),
    //   "lastName":new FormControl("",Validators.required),
    //   "password":new FormControl("",Validators.required)
      
    // })
    */

    /*
    Second way
    */
    this.registerReactive = this.fb.group(
      {
        firstName: ['', { validators: [Validators.required, Validators.minLength(3)], updateOn: "blur" }],
        lastName: ['', { validators: [Validators.required, Validators.minLength(3)], updateOn: "blur" }],
        password: ['', { validators: [Validators.required, Validators.minLength(8), passwordStrengthValidator()] ,updateOn:"blur"}],
        confirmPassword: ["", { validators: [Validators.required, Validators.minLength(8)] }]

      },
      {
        validators: [
          checkPasswordMatching('password','confirmPassword')
        ],
        updateOn:"change"
      }
    )


  }
  submitEventHandler() {
    console.log("Reactive Register Form submitted", this.registerReactive);
  }
  get lastName() {
    return this.registerReactive.controls['lastName'];
  }
  get password() {
    return this.registerReactive.controls['password'];
  }
  get confirmPassword() {
    return this.registerReactive.controls['confirmPassword'];
  }
}

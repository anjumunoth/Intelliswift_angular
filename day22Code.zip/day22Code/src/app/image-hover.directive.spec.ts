import { ImageHoverDirective } from './image-hover.directive';

describe('ImageHoverDirective', () => {
  it('should create an instance', () => {
    const directive = new ImageHoverDirective();
    expect(directive).toBeTruthy();
  });
});

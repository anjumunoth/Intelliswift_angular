import { Component } from '@angular/core';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {
  dbStartDate:Date;
  signInEventHandler(registerForm:any)
  {
    console.log("Form values",registerForm.value);
  }
  displayStartDate(ev:any)
  {
    console.log("date selected",ev.target.value);
  }
  constructor()
  {
    var today=new Date();
    this.dbStartDate=new Date((today.getFullYear()) -100,0,1);
  }
}

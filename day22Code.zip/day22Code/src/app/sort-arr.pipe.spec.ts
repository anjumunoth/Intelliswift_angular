import { SortArrPipe } from './sort-arr.pipe';

describe('SortArrPipe', () => {
  it('create an instance', () => {
    const pipe = new SortArrPipe();
    expect(pipe).toBeTruthy();
  });
});

import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { SamplePipeExamplesComponent } from './sample-pipe-examples/sample-pipe-examples.component';
import { ProductSearchComponent } from './product-search/product-search.component';
import { SortExampleComponent } from './sort-example/sort-example.component';
import { ProductManageComponent } from './product-manage/product-manage.component';
import { BindingExamplesComponent } from './binding-examples/binding-examples.component';
import { CustomDirectiveExamplesComponent } from './custom-directive-examples/custom-directive-examples.component';
import { HomeComponent } from './home/home.component';
import { Page404Component } from './page404/page404.component';

const routes: Routes = [
 
  {path:"",redirectTo:"home", pathMatch:"full"},
  {path:"login",component:LoginComponent},
  {path:"register",component:RegisterComponent},
  {path:"pipe",component:SamplePipeExamplesComponent},
  {path:"search",component:ProductSearchComponent},
  {path:"sortPage",component:SortExampleComponent},
  {path:"product-manage",component:ProductManageComponent},
  {path:"BINDINGEXAMPLES",component:BindingExamplesComponent},
  {path:"customdirectives",component:CustomDirectiveExamplesComponent},
  {path:"home",component:HomeComponent},
  {path:"**",component:Page404Component}
 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

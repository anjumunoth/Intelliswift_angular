import { Component, EventEmitter, Output,Input } from '@angular/core';
import {Products} from "../products"

@Component({
  selector: 'app-products-list',
  templateUrl: './products-list.component.html',
  styleUrls: ['./products-list.component.css']
})
export class ProductsListComponent {
@Output() sendCartObjFromPlToHome:EventEmitter<any>;

  @Input() productsArr:Array<Products>;
  //productsArr1:Products[];
  mycolours:string[];
  showAddToCart:boolean;
  isDisabled:boolean;
  temp:number;
  companyName:string;
  selectedProduct:Products | null;
  constructor()
  {
    this.sendCartObjFromPlToHome=new EventEmitter<any>();
    this.selectedProduct=null;
    this.companyName="Intelliswift";
    this.isDisabled=true;
    this.temp=10;
    this.mycolours=["red","green","blue","violet"]
    this.productsArr=[];
    //this.productsArr1=[];
    this.showAddToCart=false;
    
  }
  addToCartEventHandler(selectedProduct:Products)
  {
    //alert("Button clicked " + selectedProduct.productName);
    this.showAddToCart=true;
    //alert("ShowAddTocart : "+this.showAddToCart);
    this.selectedProduct=selectedProduct;
  }

  cancelProductEventHandler()
  {
    // unmount the child AddToCart component
    this.showAddToCart=false;
  }
  confirmProductEventHandler(cartObj:any)
  {
    // unmount the child AddToCart component
    this.showAddToCart=false;
    // reduce the quantity
    //var pos=this.productsArr.findIndex(product => product.productId == cartObj.productId);// object | ud
    var selectedProduct=this.productsArr.find(product => product.productId == cartObj.productId);// object | ud
    // selectedProduct is a reference to the element in productsArr which has the same productId of the product present in cartObj
    if(selectedProduct)
      {
        selectedProduct.quantity=selectedProduct.quantity-cartObj.quantitySelected;
      }
      this.sendCartObjFromPlToHome.emit(cartObj);
  }


  

}

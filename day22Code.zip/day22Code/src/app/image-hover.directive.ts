import { Directive, ElementRef,HostBinding,HostListener,Input,OnChanges,OnInit, SimpleChanges } from '@angular/core';

@Directive({
  selector: 'img[appImageHover]'
})
export class ImageHoverDirective implements OnInit{
  @Input({alias:'appImageHover'}) imgHoverPath:string;
@HostBinding("src") imgOriginalPath:string;
  
@HostListener("mouseover") onMouseOver(){
  // assign the imagePath to src attribute;
  
  this.el.nativeElement.src=this.imgHoverPath;
}
@HostListener("mouseleave") onMouseLeave(){
  // assign the imagePath to src attribute;
 
  this.el.nativeElement.src=this.imgOriginalPath; // get the original image
}

  constructor(private el:ElementRef) { 
    this.imgHoverPath="";
    this.imgOriginalPath="";

  }
  
  ngOnInit(): void {
    this.imgOriginalPath=this.el.nativeElement.src;
    

  }


}

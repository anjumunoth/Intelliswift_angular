import { Directive } from '@angular/core';
import { AbstractControl, ValidationErrors, Validator } from '@angular/forms';
import {passwordStrengthValidator} from "../Validators/passwordStrengthValidator"

@Directive({
  selector: '[appCheckForPasswordStrength]'
})
export class CheckForPasswordStrengthDirective implements Validator {

  constructor() { }
  validate(control: AbstractControl): ValidationErrors | null {
    return passwordStrengthValidator()(control);
    
  }
  

}

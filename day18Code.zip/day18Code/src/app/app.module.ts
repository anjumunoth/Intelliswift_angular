import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { FormsModule } from '@angular/forms';


import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { SampleComponent } from 'src/components/sample/sample.component';
import { HomeComponent } from './home/home.component';
import { ProductsListComponent } from './products-list/products-list.component';
import { AddToCartComponent } from './add-to-cart/add-to-cart.component';
import { NgIfExamplesComponent } from './ng-if-examples/ng-if-examples.component';
import { ParentComponent } from './parent/parent.component';
import { ChildComponent } from './child/child.component';
import { CartComponent } from './cart/cart.component';
import { SamplePipeExamplesComponent } from './sample-pipe-examples/sample-pipe-examples.component';
import { NestedSlicePipe } from './nested-slice.pipe';
import { DisplayArrayPipe } from './display-array.pipe';
import { ProductSearchComponent } from './product-search/product-search.component';
import { SearchPipe } from './search.pipe';
import { SortExampleComponent } from './sort-example/sort-example.component';
import { SortArrPipe } from './sort-arr.pipe';
import { SwitchExampleComponent } from './switch-example/switch-example.component';
import { CustomDirectiveExamplesComponent } from './custom-directive-examples/custom-directive-examples.component';
import { CustomBackgroundColorDirective } from './custom-background-color.directive';
import { ImageHoverDirective } from './image-hover.directive';
import { CustomToolTipDirective } from './custom-tool-tip.directive';
import { BindingExamplesComponent } from './binding-examples/binding-examples.component';
import { ProductManageComponent } from './product-manage/product-manage.component';
import { EditProductComponent } from './edit-product/edit-product.component';
import { RegisterComponent } from './register/register.component';
import { CheckForPasswordStrengthDirective } from './check-for-password-strength.directive';


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    SampleComponent,
    HomeComponent,
    ProductsListComponent,
    AddToCartComponent,
    NgIfExamplesComponent,
    ParentComponent,
    ChildComponent,
    CartComponent,
    SamplePipeExamplesComponent,
    NestedSlicePipe,
    DisplayArrayPipe,
    ProductSearchComponent,
    SearchPipe,
    SortExampleComponent,
    SortArrPipe,
    SwitchExampleComponent,
    CustomDirectiveExamplesComponent,
    CustomBackgroundColorDirective,
    ImageHoverDirective,
    CustomToolTipDirective,
    BindingExamplesComponent,
    ProductManageComponent,
    EditProductComponent,
    RegisterComponent,
    CheckForPasswordStrengthDirective,
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  
  bootstrap: [AppComponent]
})
export class AppModule { }

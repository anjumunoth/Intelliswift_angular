import { Directive, ElementRef, OnInit,Input, HostListener } from '@angular/core';

// selector is in square brackets because we are going to be working with a attribute directive
@Directive({
  selector: '[appCustomBackgroundColor]'
})
export class CustomBackgroundColorDirective implements OnInit{
@Input() appCustomBackgroundColor:string;
@Input() textColor:string;

@HostListener("mouseenter") onMouseEnterEventHandler(){
  this.el.nativeElement.style.border="5px dotted pink";
}
@HostListener("mouseleave") onMouseLeaveEventHandler(){
  this.el.nativeElement.style.border=null;
}

  constructor(private el:ElementRef) { 
    this.appCustomBackgroundColor="white";
    this.textColor="black"
  }
  ngOnInit(): void {
    this.el.nativeElement.style.backgroundColor=this.appCustomBackgroundColor;
    this.el.nativeElement.style.color=this.textColor;
  }



}

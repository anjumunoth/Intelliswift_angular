import { AbstractControl } from "@angular/forms";

export function passwordStrengthValidator()
{
    return function(control:AbstractControl){
        var value=control.value;
        if(!value)
            {
                return null;
            }
        return null;
    }
}
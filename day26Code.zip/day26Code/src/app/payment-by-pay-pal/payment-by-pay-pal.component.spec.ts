import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PaymentByPayPalComponent } from './payment-by-pay-pal.component';

describe('PaymentByPayPalComponent', () => {
  let component: PaymentByPayPalComponent;
  let fixture: ComponentFixture<PaymentByPayPalComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [PaymentByPayPalComponent]
    });
    fixture = TestBed.createComponent(PaymentByPayPalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

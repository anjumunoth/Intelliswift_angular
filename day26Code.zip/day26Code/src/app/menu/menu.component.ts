import { AfterContentChecked, AfterContentInit, AfterViewChecked, AfterViewInit, Component, inject } from '@angular/core';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements AfterContentChecked, AfterContentInit,AfterViewChecked,AfterViewInit {
  isUserLoggedIn:boolean;
  authService:AuthService
  constructor()
  {
    this.authService=inject(AuthService);
    this.isUserLoggedIn=this.authService.isUserLoggedIn;

  }
  ngAfterContentInit(): void {
   console.log("ngAfterContentInit called ")
   
   
  }
  ngAfterContentChecked(): void {
    this.isUserLoggedIn=this.authService.isUserLoggedIn;
    console.log(" ngAfterContentChecked called", this.isUserLoggedIn);
    

  }
  ngAfterViewInit(): void {
    console.log("ngAfterViewInit ")
   
  }
  ngAfterViewChecked(): void {
    
    this.isUserLoggedIn=this.authService.isUserLoggedIn;
    console.log("ngAfterViewChecked", this.isUserLoggedIn);

  }

  logoutEventHandler()
  {
    this.authService.setUserLoggedOut();
  }

  

}

/*
constructor , onInit,ngAfterContentInit, ngAfterViewInit  --called only once
ngOnChanges -- whenever the @Input changes
ngDoCheck -- return boolean value; true -- continue with other lifecycle methods; false -- stop the check

*/

import { ChangeDetectionStrategy, Component, Input } from '@angular/core';

@Component({
  selector: 'app-fruit-display',
  templateUrl: './fruit-display.component.html',
  styleUrls: ['./fruit-display.component.css'],
  changeDetection:ChangeDetectionStrategy.OnPush
})
export class FruitDisplayComponent {
@Input() fruits:Array<string>;
constructor()
{
  this.fruits=[];
}
}

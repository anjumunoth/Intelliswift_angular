import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, tap } from 'rxjs';
import { Tasks } from './tasks';

@Injectable({
  providedIn: 'root'
})
export class TasksManageService {

  constructor(private httpClient:HttpClient) { }

  getAllTasks()
  {
    var serverUrl='https://dummyjson.com/todos';
    return this.httpClient.get<Array<Tasks>>(serverUrl)
    .pipe(
      map((response:any)=>{
        console.log("Response from the server for get request",response);
        return response["todos"];
      })
    )
  }
}

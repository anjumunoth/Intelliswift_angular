import { Component } from '@angular/core';

@Component({
  selector: 'app-demo',
  templateUrl: './demo.component.html',
  styleUrls: ['./demo.component.css']
})
export class DemoComponent {
  fruits:Array<string>;
  constructor()
  {
    this.fruits=["apple","strawberry","banana"]
  }
  addFruitEventHandler(fruit:string)
  {
    //this.fruits.push(fruit);// changes the original array; mutating the data
    this.fruits=[...this.fruits,fruit];// copy of array; immutability
    console.log("Fruits",this.fruits);
  }
}

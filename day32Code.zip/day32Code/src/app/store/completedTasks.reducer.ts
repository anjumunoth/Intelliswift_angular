import { createReducer, on } from "@ngrx/store";
import { Tasks } from "../tasks";
import { TasksActions } from "./task.action";

export var initialState:Array<Tasks>=[];

export var completedTasksReducer= createReducer(initialState,
    on(TasksActions.markTaskAsCompleted,(state,{task})=>{
        var newState=[...state,{...task,completed:true}];
        console.log("State after markTaskAsCompleted in completedtasksReducer",newState);
        return newState;
    })
)
// Data type of state -- Should always be an Object
// State --Can hold various kinds of information -- tasks:array, completedTasks: array
// reducer -- pure function -- state, actions
// can there be more than 1 reducer -- YES
// Multiple reducers -- seperation of concerns, modularity
// Each reducer -- can have its own slice of state
// task.reducer.ts --> tasks:array
// completedTask.reducer.ts --> completedTasks:array

import { createReducer, on } from "@ngrx/store";
import { Tasks } from "../tasks";
import { TasksActions, TasksApiActions } from "./task.action";

export var initialState:Array<Tasks>=[];
export var tasksReducer=createReducer(initialState,
    on(TasksActions.addTask,(state,{task})=>{
        return [...state,task]
    }),
    on(TasksActions.deleteTask,(state,{taskId})=>{
        var newState=[...state];
        var pos=newState.findIndex(item => item.id == taskId);
        if(pos>=0)
            {
                newState.splice(pos,1);
            }
        return newState;
    }),
    on(TasksActions.markTaskAsCompleted,(state,{task})=>{
        var newState=[...state];
        console.log(newState);
        var pos=newState.findIndex(item => item.id == task.id);
        if(pos>=0)
            {
               //newState[pos].completed=true;
               newState.splice(pos,1);//
            }
        console.log("State after markTaskAsCompleted in tasksReducer",newState);
        return newState;
    }),
    on(TasksApiActions.loadTasks,(state,{tasksArr})=>{
        return [...tasksArr];
    })

)
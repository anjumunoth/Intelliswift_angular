export interface Tasks {

    id: number;
    todo: string;
    completed: boolean;
    userId: number

}
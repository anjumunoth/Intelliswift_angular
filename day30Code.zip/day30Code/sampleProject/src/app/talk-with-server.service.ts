import { HttpClient, HttpErrorResponse, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { response } from 'express';
import { Observable, catchError, of, retry, retryWhen, switchMap, throwError, forkJoin, interval, take } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class TalkWithServerService {
  serverUrl: string;
  constructor(private httpClient: HttpClient) {
    this.serverUrl = "https://jsonplaceholder.typicode.com/"
  }

  getAllUsers() {
    this.serverUrl = "https://jsonplaceholder.typicode.com/posts";
    //GET request-- getting data from api; select query ; no need tp pass any data as part of body section; pass some header info; pass some params; pass some query string;authentication info(tokens)
    // response -- data, Content-type; header info; status code 
    // status 200, 201, 202... success code
    // 300, 301
    // 400, 401.... error codes 
    // 500 -- Interal server error
    //this.httpClient.get(this.serverUrl)

    return this.httpClient.get<Array<Object>>(this.serverUrl)
      .pipe(
        catchError(this.handleError)
      )
    // get request -- Observable with data of data type Array<Object>


  }
  private handleError(err: HttpErrorResponse) {
    if (err.status == 0) {
      // network error 
      console.log("Network or client error", err);

    }
    else {
      console.log("Error in the server", err);
    }
    return throwError(() => new Error("Error in the request"));
  }

  getProducts() {
    var serverUrl1 = "https://jsonplaceholder.typicode.com/users"
    var serverUrl2 = "https://reqres.in/api/users?page=2";
    // getting the data wrt electronics
    // getting the data wrt to groceries
    var parallel$ = forkJoin([
      this.httpClient.get(serverUrl1),
      this.httpClient.get(serverUrl2)
    ]
    );
    return parallel$;
  }

  sequentialRequests() {

    var serverUrl = "https://reqres.in/api/users/"
    var getServerUrl = "https://reqres.in/api/unknown/2";
    var sequential$=this.httpClient.get(getServerUrl)
      .pipe(
        switchMap((user:any) => {
          
          var id = user?.data?.id;
          console.log("Id of product to be deleted",id);
          var params = new HttpParams().set("id", id);
          console.log(params);
          return this.httpClient.delete(serverUrl, { params })
        },
        (getHttpResult,deleteHttpResult)=>{
          return [getHttpResult,deleteHttpResult]
        }
      )
      )
   
   return sequential$;
    }
  
    addPosts()
    {
      this.serverUrl="https://jsonplaceholder.typicode.com/posts";
      var data=JSON.stringify({
        title: 'foo',
        body: 'bar',
        userId: 1,
      });
      const reqHeaders=new HttpHeaders().set("content-type",'application/json; charset=UTF-8')
      return this.httpClient.post(this.serverUrl,data,{headers:reqHeaders,observe:"response"}).pipe(
        catchError(this.handleError)
      )
    }

    putPosts(userId:number,data:any)
    {
      // put -- update a user 
      // updation -- id, updatedData
      // how to pass id -- as params -- HttpParams
      // how to pass updated data --- as body create a json object;
      // reponse -- observe : response
      // Request Header Info
      this.serverUrl="https://jsonplaceholder.typicode.com/posts/"+userId;
      var params=new HttpParams().set("id",userId);// query string
      var reqHeaders=new HttpHeaders().set("content-type",'application/json; charset=UTF-8');
      var bodyData=JSON.stringify(data);
      return this.httpClient.put(this.serverUrl,bodyData,{headers:reqHeaders,observe:"response"})
      .pipe(
        catchError(this.handleError)
      )

    }

    searchData(searchText:string)
    {
      console.log("Search text in service",searchText);
      // give a get request
      return interval(3000).pipe(take(5));

    }
}

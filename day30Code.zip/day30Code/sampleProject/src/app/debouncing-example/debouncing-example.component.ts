import { Component, OnInit } from '@angular/core';
import { Observable, Subject, debounceTime, distinctUntilChanged, switchMap } from 'rxjs';
import { TalkWithServerService } from '../talk-with-server.service';

@Component({
  selector: 'app-debouncing-example',
  templateUrl: './debouncing-example.component.html',
  styleUrls: ['./debouncing-example.component.css']
})
export class DebouncingExampleComponent implements OnInit{
  private searchText$:Subject<string>;
  numbersObs$:Observable<number>;
  constructor(private talkWithServer:TalkWithServerService) {
    this.searchText$=new Subject<string>();
    this.numbersObs$=new Observable<number>();
  }
  keyUpEventHandler(ev:any)
  {
    console.log("Value entered",ev.target.value);
    this.searchText$.next(ev.target.value);
  }
  ngOnInit(): void {
    this.numbersObs$=this.searchText$.pipe(
      debounceTime(5000),
      distinctUntilChanged(),
      switchMap(searchtext=> this.talkWithServer.searchData(searchtext))
    )
  }
}

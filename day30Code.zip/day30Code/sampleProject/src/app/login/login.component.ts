import { Component } from '@angular/core';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  serverErrors: string;
  constructor(private authService: AuthService, private router: Router) {
    this.serverErrors = "";
  }
  loginEventHandler(loginForm: any) {
    // validations are successful;
    var result = this.authService.loginUser(loginForm.value.emailId, loginForm.value.password);
    if (result.status) {
      alert("Login successful");
      this.router.navigate(["home"]);
    }
    else {
      this.serverErrors = result.message;
      alert(this.serverErrors)
    }
  }
}


import { Component, Input } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css']
})
export class ProductDetailsComponent {
  @Input() pId:string;
  selectedProductId: string|null;
  constructor(private activatedRoute:ActivatedRoute)
  {
    //this.selectedProductId=this.activatedRoute.snapshot.params["pId"]
    this.selectedProductId=this.activatedRoute.snapshot.paramMap.get("pId");
    this.pId="";
  }
}

import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { SamplePipeExamplesComponent } from './sample-pipe-examples/sample-pipe-examples.component';
import { ProductSearchComponent } from './product-search/product-search.component';
import { SortExampleComponent } from './sort-example/sort-example.component';
import { ProductManageComponent } from './product-manage/product-manage.component';
import { BindingExamplesComponent } from './binding-examples/binding-examples.component';
import { CustomDirectiveExamplesComponent } from './custom-directive-examples/custom-directive-examples.component';
import { HomeComponent } from './home/home.component';
import { Page404Component } from './page404/page404.component';
import { ProductDetailsComponent } from './product-details/product-details.component';
import { PaymentsComponent } from './payments/payments.component';
import { PaymentByCardComponent } from './payment-by-card/payment-by-card.component';
import { PaymentByWireTransferComponent } from './payment-by-wire-transfer/payment-by-wire-transfer.component';
import { combineLatest } from 'rxjs';
import { PaymentByPayPalComponent } from './payment-by-pay-pal/payment-by-pay-pal.component';
import { PaymentByApplePayComponent } from './payment-by-apple-pay/payment-by-apple-pay.component';
import { checkPaymentsGuard } from './check-payments.guard';
import { AuthGuard } from 'src/Guards/AuthGuard';
import { UsersManageComponent } from './users-manage/users-manage.component';

const routes: Routes = [
 
  {path:"",redirectTo:"home", pathMatch:"full"},
  {path:"users",component:UsersManageComponent},
  {path:"login",component:LoginComponent},
  {path:"register",component:RegisterComponent},
  {path:"pipe",component:SamplePipeExamplesComponent},
  {path:"search",component:ProductSearchComponent},
  {path:"sortPage",component:SortExampleComponent},
  {path:"product-manage",component:ProductManageComponent},
  {path:"BINDINGEXAMPLES",component:BindingExamplesComponent},
  {path:"customdirectives",component:CustomDirectiveExamplesComponent},
  {path:"home",component:HomeComponent},
  {path:"product-details",component:ProductDetailsComponent},
  {path:"product-details/:pId",component:ProductDetailsComponent},
  {path:"payments",component:PaymentsComponent,
    canActivate:[AuthGuard],
    children:[
      {path:"paymentByCard",component:PaymentByCardComponent},
      {path:"paymentByWireTransfer",component:PaymentByWireTransferComponent},
      {path:"paymentByPayPal",component:PaymentByPayPalComponent},
      {path:"paymentByApplePay",component:PaymentByApplePayComponent},
  
  ]},
  {path:"**",component:Page404Component}
 
];

@NgModule({
  imports: [RouterModule.forRoot(routes,{bindToComponentInputs:true})],
  exports: [RouterModule]
})
export class AppRoutingModule { }

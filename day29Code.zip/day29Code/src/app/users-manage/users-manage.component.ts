import { Component, OnInit, inject } from '@angular/core';
import { TalkWithServerService } from '../talk-with-server.service';
import { BehaviorSubject, Observable, Subject } from 'rxjs';

@Component({
  selector: 'app-users-manage',
  templateUrl: './users-manage.component.html',
  styleUrls: ['./users-manage.component.css']
})
export class UsersManageComponent implements OnInit {
  talkWithServer: TalkWithServerService;
  usersArr: Array<Object>;
  usersObs$: Observable<Array<Object>>;
  usersSub: Subject<Array<Object>>;
  usersBehaviourSubject: BehaviorSubject<Array<Object>>;
  constructor() {
    this.talkWithServer = inject(TalkWithServerService);
    this.usersArr = [];
    this.usersObs$ = new Observable<Array<Object>>();
    this.usersSub = new Subject<Array<Object>>();
    this.usersBehaviourSubject = new BehaviorSubject<Array<Object>>([]);
  }
  ngOnInit(): void {
    this.talkWithServer.getAllUsers()
      .subscribe({
        next: (response) => {
          console.log(`Response of get request : ${JSON.stringify(response)}`)
          this.usersArr = response;
        }



      }
      );

    this.talkWithServer.getProducts()
      .subscribe(values => {
        console.log("Result of parallel Observables", values);
      })

    this.talkWithServer.sequentialRequests()
      .subscribe(values => {
        console.log("Multiple request in sequential", values);
      })



    //  this.usersObs$=this.talkWithServer.getAllUsers();
    // this.talkWithServer.getAllUsers().subscribe(this.usersSub);
    // setInterval(()=>{  this.talkWithServer.getAllUsers().subscribe(this.usersBehaviourSubject);
    // },5000);
    // }

  }
  addUserEventHandler()
  {
    this.talkWithServer.addPosts()
    .subscribe((response)=>{
      console.log("Post response ",response);
      var data=JSON.parse(JSON.stringify(response));
      this.usersArr.push(data.body);
    })
  }
  editEventHandler(user:any)
  {
    user.title="angular";
    this.talkWithServer.putPosts(user.userId,user)
    .subscribe((response)=>{
        console.log("Response of put request",response)
    })
  }

}
// constructor will be executed and then UI will be loaded and then ngOnInit will be executed

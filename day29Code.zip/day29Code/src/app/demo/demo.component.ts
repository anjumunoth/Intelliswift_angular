import { Component, inject } from '@angular/core';
import { AuthService } from '../auth.service';
import { CounterService } from '../counter.service';

@Component({
  selector: 'app-demo',
  templateUrl: './demo.component.html',
  styleUrls: ['./demo.component.css']
})
export class DemoComponent {
  //authService:AuthService;
  //ctrService:CounterService;
  ctr:number;
  constructor(private ctrService:CounterService)
  {

    //this.ctrService=new CounterService();// this should not be done
   // this.ctrService=inject(CounterService);// create it as a singleton
    this.ctr=this.ctrService.ctr;
  }
  changeCtrEventHandler(op:string)
  {
    if(op=="inc")
      {
        this.ctr=this.ctrService.incCtr();
      }
      else
      {
        this.ctr=this.ctrService.decCtr();
      }
  }
}

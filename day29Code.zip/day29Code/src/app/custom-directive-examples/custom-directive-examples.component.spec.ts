import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomDirectiveExamplesComponent } from './custom-directive-examples.component';

describe('CustomDirectiveExamplesComponent', () => {
  let component: CustomDirectiveExamplesComponent;
  let fixture: ComponentFixture<CustomDirectiveExamplesComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CustomDirectiveExamplesComponent]
    });
    fixture = TestBed.createComponent(CustomDirectiveExamplesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

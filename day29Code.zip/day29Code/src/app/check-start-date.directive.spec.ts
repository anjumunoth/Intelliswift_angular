import { CheckStartDateDirective } from './check-start-date.directive';

describe('CheckStartDateDirective', () => {
  it('should create an instance', () => {
    const directive = new CheckStartDateDirective();
    expect(directive).toBeTruthy();
  });
});
